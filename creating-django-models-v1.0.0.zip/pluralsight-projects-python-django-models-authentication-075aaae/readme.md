# Setup

See tasks_module0.md for setup instructions

# Run tests by using Django Test on the module folders

`python manage.py test module2`
